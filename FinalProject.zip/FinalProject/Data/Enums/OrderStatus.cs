﻿namespace FinalProject.Data.Enum
{
    public enum OrderStatus
    {
        Pending = 1,
        Delivered,
        Completed
    }
}
