﻿namespace FinalProject.Data.Enum
{
    public enum ProductCategory
    {
        Electrico = 1,
        Ropa,
        Mueble 
    }
}
