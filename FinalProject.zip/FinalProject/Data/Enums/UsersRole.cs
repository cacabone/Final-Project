﻿namespace FinalProject.Data.Enum
{
    public enum UsersRole
    {
        User = 1,
        Admin
    }
}
